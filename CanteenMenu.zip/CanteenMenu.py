import xlrd
from datetime import datetime
from datetime import date
from dateutil.relativedelta import relativedelta
from PIL import ImageTk
import PIL
from Tkinter import *
import tkinter.messagebox

window = Tk()

# Initialization
# Window Configuration to appear at center of screen
window.geometry('%dx%d+%d+%d' % (690, 310, ((window.winfo_screenwidth() / 2) - (690 / 2)), ((window.winfo_screenheight() / 2) - (310 / 2))))
window.resizable(False, False)
window.title("Today's Canteen Menu")

menuUpToDate = FALSE
sheetMatch = 0
rowMatch = 0
colMatch = 0
lunchCount = 0
excel_location = "C:/Users/GOK5COB/Desktop/Copy of IntranetMenu.xlsx"
#excel_location = "//bosch.com/dfsrb/DfsIN/LOC/Cob/FCM/fcm-cob/team/01.CANTEEN_MENU_INTRANET/IntranetMenu.xlsx"
excel_workbook = xlrd.open_workbook(excel_location)

# Start of imageDisplay
def BaseDisplay():
    Label(window, text="                Breakfast", relief=GROOVE).place(x=10, y=10, height=50, width=190)
    Label(window, text=" : ").place(x=200, y=10, height=50, width=10)
    Label(window, text=" + ").place(x=470, y=10, height=50, width=10)
    Label(window, text="Bread, Butter, Jam", relief=GROOVE).place(x=480, y=10, height=50, width=140)
    Label(window, text=" + ").place(x=620, y=10, height=50, width=10)

    Label(window, text="                Indian Breads / Pancakes\n              Gravy / Chutney", relief=GROOVE).place( x=10, y=70, height=50, width=190)
    Label(window, text=" : ").place(x=200, y=70, height=50, width=10)
    Label(window, text="                Main Course", relief=GROOVE).place(x=10, y=130, height=50, width=190)
    Label(window, text=" : ").place(x=200, y=130, height=50, width=10)

    Label(window, text="                Dessert / Juice / Fruits", relief=GROOVE).place(x=10, y=190, height=50, width=190)
    Label(window, text=" : ").place(x=200, y=190, height=50, width=10)
    Label(window, text="                Snacks", relief=GROOVE).place(x=10, y=250, height=50, width=190)
    Label(window, text=" : ").place(x=200, y=250, height=50, width=10)
    Label(window, text=" + ").place(x=510, y=250, height=50, width=10)

    coffee_photo = ImageTk.PhotoImage(PIL.Image.open("coffee.png").resize((50, 50), PIL.Image.ANTIALIAS))
    breakfast_photo = ImageTk.PhotoImage(PIL.Image.open("dosa.png").resize((40, 40), PIL.Image.ANTIALIAS))
    starter_photo = ImageTk.PhotoImage(PIL.Image.open("lunch_starter.png").resize((40, 40), PIL.Image.ANTIALIAS))
    Lunch_m_photo = ImageTk.PhotoImage(PIL.Image.open("ricecurry.png").resize((40, 40), PIL.Image.ANTIALIAS))
    dessert_photo = ImageTk.PhotoImage(PIL.Image.open("juice1.png").resize((40, 40), PIL.Image.ANTIALIAS))
    snacks_photo = ImageTk.PhotoImage(PIL.Image.open("samosa.png").resize((40, 40), PIL.Image.ANTIALIAS))

    tempLabel = Label(image=coffee_photo)
    tempLabel.photo = coffee_photo
    tempLabel.place(x=630, y=10, height=50, width=50)
    tempLabel = Label(image=coffee_photo)
    tempLabel.photo = coffee_photo
    tempLabel.place(x=520, y=250, height=50, width=50)

    tempLabel = Label(image=breakfast_photo)
    tempLabel.photo = breakfast_photo
    tempLabel.place(x=15, y=15, height=40, width=40)

    tempLabel = Label(image=starter_photo)
    tempLabel.photo = starter_photo
    tempLabel.place(x=15, y=75, height=40, width=40)

    tempLabel = Label(image=Lunch_m_photo)
    tempLabel.photo = Lunch_m_photo
    tempLabel.place(x=15, y=135, height=40, width=40)

    tempLabel = Label(image=dessert_photo)
    tempLabel.photo = dessert_photo
    tempLabel.place(x=15, y=195, height=40, width=40)

    tempLabel = Label(image=snacks_photo)
    tempLabel.photo = snacks_photo
    tempLabel.place(x=15, y=255, height=40, width=40)

# End of Image Content

def SpecialDisplay():
    star_photo = ImageTk.PhotoImage(PIL.Image.open("star1.png").resize((15, 15), PIL.Image.ANTIALIAS))
    t1 = Label(image=star_photo)
    t1.photo = star_photo
    t1.place(x=215, y=75, height=15, width=15)
    t2 = Label(image=star_photo)
    t2.photo = star_photo
    t2.place(x=215, y=135, height=15, width=15)
    t3 = Label(image=star_photo)
    t3.photo = star_photo
    t3.place(x=215, y=195, height=15, width=15)

# Start of getCurrentDate
def getCurrentDate():
    return datetime.now().strftime("%d.%m.%Y")
# End of getCurrentDate


# Start of getTomorrowDate
def getTomorrowDate():
    return (datetime.now() + relativedelta(days=1)).strftime("%d.%m.%Y")
# End of getTomorrowDate


# Start of findTodayMenu
def SearchMenu(inputdate):
    for sheet in excel_workbook.sheets():
        for row in range(sheet.nrows):
            for col in range(sheet.ncols):
                if sheet.cell(row,col).ctype == xlrd.XL_CELL_DATE:
                    tempCellVal = sheet.cell(row, col).value
                    cellValAsTuple = xlrd.xldate_as_tuple(tempCellVal, excel_workbook.datemode)
                    rawDerivedDate = datetime(*cellValAsTuple)
                    derivedDate = rawDerivedDate.strftime("%d.%m.%Y")
                    if inputdate == derivedDate:
                        global menuUpToDate, sheetMatch, rowMatch, colMatch
                        menuUpToDate = TRUE
                        sheetMatch = sheet; rowMatch = row; colMatch = col;
                        break
                    else:
                        menuUpToDate = FALSE
            else:
                continue
            break
        else:
            continue
        break
# End of findTodayMenu


# Start of displayBreakfast
def DisplayBreakfast(sheetDetails):
    breakfast = sheetDetails[0].cell_value(sheetDetails[1], sheetDetails[2] + 2)
    if sheetDetails[0].cell_type(sheetDetails[1], sheetDetails[2] + 2) == xlrd.XL_CELL_EMPTY:
        Label(window, text=" - ", wraplength=250, relief=GROOVE).place(x=210, y=10, height=50, width=470)
    else:
        Label(window, text=breakfast, wraplength=250, relief=GROOVE).place(x=210, y=10, height=50, width=260)
# End of displayBreakfast

# Start of displayLunch
def DisplayLunch(sheetDetails):
    starter = mainCourse = ''
    global lunchCount
    for i in range(3, 5):
        starter += sheetDetails[0].cell_value(sheetDetails[1], sheetDetails[2] + i)
        if i != 4:
            starter += ' , '

    Label(window, text=starter, relief=GROOVE, wraplength=450).place(x=210, y=70, height=50, width=470)

    for j in range(5,9):
        mainCourse += sheetDetails[0].cell_value(sheetDetails[1], sheetDetails[2] + j)
        if j != 8:
            mainCourse += ' , '

    Label(window, text=mainCourse, relief=GROOVE, wraplength=440).place(x=210, y=130, height=50, width=470)

    desContent = sheetDetails[0].cell_value(sheetDetails[1], sheetDetails[2] + 9)
    Label(window, text=desContent, relief=GROOVE,wraplength=350).place(x=210, y=190, height=50, width=360)

    lunchCount = len(starter) + len(mainCourse) + len(desContent)
# End of displayLunch


# Start of displaySnacks
def DisplaySnacks(sheetDetails):
    snacksContent = sheetDetails[0].cell_value(sheetDetails[1], sheetDetails[2] + 10)
    if sheetDetails[0].cell_type(sheetDetails[1], sheetDetails[2] + 10) == xlrd.XL_CELL_EMPTY:
        Label(window, text=" - ", relief=GROOVE, wraplength=290).place(x=210, y=250, height=50, width=360)
    else:
        Label(window, text=snacksContent, relief=GROOVE, wraplength=290).place(x=210, y=250, height=50, width=300)
# End of Snacks


# Start of UpdateWindowDetails
def UpdateWindowDetails(select):
    d1 = getCurrentDate()
    d2 = getTomorrowDate()
    if select == 0:
        window.title("Today's Canteen Menu: " + d1)
    else:
        window.title("Tomorrow's Canteen Menu: " + d2)
# Start of UpdateWindowDetails

# Start of UpdateMenu
def UpdateMenu(displayflag):
    if displayflag == 0:
        curdate = getTomorrowDate()
        UpdateWindowDetails(1)
    else:
        curdate = getCurrentDate()
        UpdateWindowDetails(0)
    SearchMenu(curdate)
    global menuUpToDate, sheetMatch, rowMatch, colMatch
    if menuUpToDate == TRUE:
        sheetDetails2 = [sheetMatch, rowMatch, colMatch]
        DisplayBreakfast(sheetDetails2)
        DisplayLunch(sheetDetails2)
        DisplaySnacks(sheetDetails2)
    else:
        tkinter.messagebox.showinfo("Sorry !!", "Menu not updated for " + curdate + "!!")
        UpdateWindowDetails(0)
# End of UpdateMenu


# # Start of TriggerMenuChange
# def TriggerMenuChange(event):
#     if event.delta == -120:
#         UpdateMenu(1)
#     if event.delta == 120:
#         UpdateMenu(0)
# # End of TriggerMenuChange

# Start of TriggerMenuChange
def TriggerMenuChange(event):
    if event.delta == -120:
        today_main()
    if event.delta == 120:
        tomorrow_main()
# End of TriggerMenuChange


def specialLunchCheck():
    print(lunchCount)
    if lunchCount > 160:
        SpecialDisplay()


####################################################################################################################

# Main Functionality
# def main():
#     sundayCheck = date.today().weekday()
#     if sundayCheck != 6:
#         currentDate = getCurrentDate()
#         SearchMenu(currentDate)
#         if menuUpToDate == TRUE:
#             sheetDetails1 = [sheetMatch, rowMatch, colMatch]
#             DisplayBreakfast(sheetDetails1)
#             DisplayLunch(sheetDetails1)
#             DisplaySnacks(sheetDetails1)
#             UpdateWindowDetails(0)
#             BaseDisplay()
#             # Button(window, text='<', command= lambda: UpdateMenu(1)).place(x=10, y=310, height=20, width=330)
#             # Button(window, text='>', command= lambda: UpdateMenu(0)).place(x=350, y=310, height=20, width=330)
#             window.bind("<MouseWheel>", TriggerMenuChange)
#         else:
#             tkinter.messagebox.showinfo("Sorry !!", "Menu not updated for " + currentDate + "!!")
#             window.destroy()
#     else:
#         tkinter.messagebox.showinfo("Not Cool !!", "Go Home, It is a Sunday !!")
#         window.destroy()

def today_main():
    lcl_sunday1 = date.today().weekday()
    if (lcl_sunday1) != 6:
        lcl_date1 = getCurrentDate()
        SearchMenu(lcl_date1)
        if menuUpToDate == TRUE:
            BaseDisplay()
            sheetDetails1 = [sheetMatch, rowMatch, colMatch]
            DisplayBreakfast(sheetDetails1)
            DisplayLunch(sheetDetails1)
            DisplaySnacks(sheetDetails1)
            specialLunchCheck()
        else:
            tkinter.messagebox.showinfo("Sorry !!", "Menu not updated for " + lcl_date1 + "!!")
            window.destroy()
    else:
        tkinter.messagebox.showinfo("Not Cool !!", "Go Home, It is a Sunday !!")
        window.destroy()

def tomorrow_main():
    lcl_sunday2 = date.today().weekday()
    if (lcl_sunday2 + 1) != 6:
        lcl_date2 = getTomorrowDate()
        SearchMenu(lcl_date2)
        if menuUpToDate == TRUE:
            sheetDetails2 = [sheetMatch, rowMatch, colMatch]
            BaseDisplay()
            DisplayBreakfast(sheetDetails2)
            DisplayLunch(sheetDetails2)
            DisplaySnacks(sheetDetails2)
            specialLunchCheck
        else:
            tkinter.messagebox.showinfo("Sorry !!", "Menu not updated for " + lcl_date2 + "!!")
            window.destroy()
    else:
        tkinter.messagebox.showinfo("Not Cool !!", "Go Home, It is a Sunday !!")
        window.destroy()

def master_main():
    Button(window, text=u"Bon Appetit !!", command=window.quit, bd=2).place(x=580, y=190, height=110, width=100)
    today_main()
    window.bind("<MouseWheel>", TriggerMenuChange)

master_main()
window.mainloop()